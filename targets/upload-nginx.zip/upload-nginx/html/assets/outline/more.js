(function() {
  __ant_icon_load({
      name: 'more',
      theme: 'outline',
      icon: '<svg viewBox="64 64 896 896" focusable="false"><path d="M456 231a56 56 0 10112 0 56 56 0 10-112 0zm0 280a56 56 0 10112 0 56 56 0 10-112 0zm0 280a56 56 0 10112 0 56 56 0 10-112 0z" /></svg>'
  });
})()