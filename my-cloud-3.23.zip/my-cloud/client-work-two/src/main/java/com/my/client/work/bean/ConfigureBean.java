package com.my.client.work.bean;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Configuration;

@Configuration
@Data
@RefreshScope
public class ConfigureBean {

    @Value("${spring.application.name}")
    private String application;

    @Value("${server-client:还没有输入}")
    private String workTwoUri;

    @Value("${spring.cloud.nacos.server-addr}")
    private String nacos;

    @Value("${test.code}")
    private String testCode;

    @Value("${server.port")
    private String port;

    @Value("${alias.port:${server.port:8080}}")
    private String aliasPort;

    @Value("${alias.name:${spring.application.name}}")
    private String aliasName;
}
