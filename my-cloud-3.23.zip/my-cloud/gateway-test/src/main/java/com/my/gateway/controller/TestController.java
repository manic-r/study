package com.my.gateway.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping(value = "/test")
@RefreshScope
public class TestController {

    @Value("${test.code}")
    private String testCode;

    @Value("${server.port}")
    private String port;

    @Value("${spring.application.name}")
    private String name;

    @GetMapping(value = "/index")
    public Map<String, Object> index() {
        System.err.println(testCode);
        return new HashMap<>() {
            {
                put("方法名", "TestController > index");
                put("testCode", testCode);
                put("执行端口号", port);
                put("执行项目", name);
            }
        };
    }
}
