package com.my.client.work.controller;

import com.my.client.work.bean.ConfigureBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping(value = "/test")
public class TestController {
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private ConfigureBean configure;

    @GetMapping(value = "/index")
    public Map<String, Object> index() {
        Map<String, Object> feign = null;
        if (!StringUtils.isEmpty(configure.getWorkTwoUri()) && !"还没有输入".equals(configure.getWorkTwoUri())) {
            feign = restTemplate.getForEntity("http://client-work-two" + configure.getWorkTwoUri(), Map.class).getBody();
        }
        Map<String, Object> finalFeign = feign;
        return new HashMap<>() {
            {
                put("方法名", "TestController > index");
                put("testCode", configure.getTestCode());
                put("执行端口号", configure.getAliasPort());
                put("执行项目", configure.getAliasName());
                put("_获取结果", finalFeign == null ? "暂无请求配置": finalFeign);
            }
        };
    }
}
